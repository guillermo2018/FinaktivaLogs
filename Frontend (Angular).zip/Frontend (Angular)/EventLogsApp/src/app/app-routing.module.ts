import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FormularioRegistroEventoComponent } from './formulario-registro-evento/formulario-registro-evento.component';
import { ConsultaEventosComponent } from './consulta-eventos/consulta-eventos.component';
import { HttpClientModule } from '@angular/common/http';

const routes: Routes = [
  { path: 'registro-evento', component: FormularioRegistroEventoComponent },
  { path: 'consulta-eventos', component: ConsultaEventosComponent },
  { path: '', redirectTo: '/registro-evento', pathMatch: 'full' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes),HttpClientModule,],
  exports: [RouterModule],
})
export class AppRoutingModule {}
