import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FormularioRegistroEventoComponent } from './formulario-registro-evento.component';

describe('FormularioRegistroEventoComponent', () => {
  let component: FormularioRegistroEventoComponent;
  let fixture: ComponentFixture<FormularioRegistroEventoComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [FormularioRegistroEventoComponent]
    });
    fixture = TestBed.createComponent(FormularioRegistroEventoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
