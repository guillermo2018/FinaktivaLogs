// formulario-registro-evento.component.ts
import { Component } from '@angular/core';
import { EventosService } from '../eventos.service';

@Component({
  selector: 'app-formulario-registro-evento',
  templateUrl:'./formulario-registro-evento.component.html',
  styleUrls: ['./formulario-registro-evento.component.css']
})
export class FormularioRegistroEventoComponent {
  evento: any = {};

  constructor(private eventosService: EventosService) {}

  registrarEvento() {
    this.eventosService.registrarEvento(this.evento).subscribe(() => {
      // Limpiar el formulario o mostrar un mensaje de éxito
      this.evento = {};
    });
  }
}
