// consulta-eventos.component.ts
import { Component } from '@angular/core';
import { EventosService } from '../eventos.service';

@Component({
  selector: 'app-consulta-eventos',
  templateUrl:'./consulta-eventos.component.html',
  styleUrls: ['./consulta-eventos.component.css']
})
export class ConsultaEventosComponent {
  filtroTipoEvento: string = '';
  filtroFechaInicio: string = '';
  filtroFechaFin: string = '';
  eventos: any[] = [];

  constructor(private eventosService: EventosService) {}

  consultarEventos() {
    console.log("Consultar evento.....");
    this.eventosService
      .consultarEventos(this.filtroTipoEvento, this.filtroFechaInicio, this.filtroFechaFin)
      .subscribe((eventos) => {
        this.eventos = eventos;
      });
  }
}