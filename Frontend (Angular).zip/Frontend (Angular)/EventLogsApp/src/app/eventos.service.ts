// eventos.service.ts
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root',
})
export class EventosService {
  private baseUrl = 'https://localhost:7251'; // Reemplaza con la URL de tu backend

  constructor(private http: HttpClient) {}

  public registrarEvento(evento: any): Observable<any> {
    console.log("datos: ", evento);
    return this.http.post<any>(`${this.baseUrl}/api/EventLogs`, evento);
  }

  public consultarEventos(tipoEvento: string, fechaInicio: string, fechaFin: string): Observable<any[]> {
    // Construye la URL de consulta según los filtros
    
    let url = `${this.baseUrl}/api/EventLogs/filtrar?`;

    if (tipoEvento) {
      url += `tipoEvento=${tipoEvento}&`;
    }
    if (fechaInicio) {
      url += `fechaInicio=${fechaInicio}&`;
    }
    if (fechaFin) {
      url += `fechaFin=${fechaFin}&`;
    }
    console.log("datos22: ", url);
    return this.http.get<any[]>(url);
  }
}